import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allbooks',
  templateUrl: './allbooks.component.html',
  styleUrls: ['./allbooks.component.css']
})
export class AllbooksComponent implements OnInit {
  
  constructor() {
  }
  ngOnInit(): void {
  }

}
