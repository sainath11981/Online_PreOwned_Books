import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sellbook',
  templateUrl: './sellbook.component.html',
  styleUrls: ['./sellbook.component.css']
})
export class SellbookComponent implements OnInit {

  register:any = {};
  constructor(private router: Router) { }
  ngOnInit(): void {
  }

}
